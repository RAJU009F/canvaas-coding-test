
class EvenNumbers():
	def __init__(self, first, last):
		
		self.first = first
		self.last = last
		self.result = []
		
	def even_digit_numbers(self):
		
		for n in range(self.first, self.last+1):
			str_n = str(n) 
			if int(str_n[0])%2 == 0 and int(str_n[1])%2 == 0 and int(str_n[2])%2 == 0 and int(str_n[3])%2 == 0 :	
				self.result.append(str_n)
		print (",".join(self.result))
		
if __name__ == '__main__':
	en = EvenNumbers(1000, 3000)
	en.even_digit_numbers()		
