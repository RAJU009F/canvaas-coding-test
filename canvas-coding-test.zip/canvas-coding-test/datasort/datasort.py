import pandas as pd 

class SortData():
	def __init__(self, in_path, out_path):
		self.in_path = in_path 
		self.out_path = out_path
		self.unsorted_df = pd.read_csv(self.in_path)
		self.sorted_df = pd.DataFrame()
	
	def sort(self):
		self.sorted_df  = self.unsorted_df.sort(['Device_ID', 'Date'], ascending=[True, True])
		self.sorted_df.to_csv(self.out_path, encoding='utf-8', index=False)
		
		
if __name__ == '__main__':
	sd = SortData('/home/hduser/RAJ/canvas-coding-test/datasort/input/large_data.csv', '/home/hduser/RAJ/canvas-coding-test/datasort/output/large_data_sorted.csv')		
	sd.sort()
