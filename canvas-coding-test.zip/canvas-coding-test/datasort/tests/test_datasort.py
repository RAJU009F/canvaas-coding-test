#import unittest
import pytest
from datasort import SortData

'''
Test basic functionality
'''
class TestSortData():
	
	def setUp(self):
		self.sd = SortData('/home/hduser/RAJ/canvas-coding-test/datasort/input/random_data.csv', '/home/hduser/RAJ/canvas-coding-test/datasort/output/random_data_sorted.csv')
		
	def test_init(self):
		# check the input files
		self.assertEqual(self.sd.in_path, '/home/hduser/RAJ/canvas-coding-test/datasort/input/random_data.csv')
		self.assertEqual(self.sd.out_path, '/home/hduser/RAJ/canvas-coding-test/datasort/output/random_data_sorted.csv')
	
	def test_sort(self):
		self.sd.sort()
		# check the number of records in sorted files
		self.assertEqual(len(self.sd.unsorted), len(self.sd.sorted_df))

# TODO
'''
cas-1
give ifferent range  of numbers only 4 digits

'''


		
if __name__ == '__main__':
	t = TestEvenNumbers()
	t.setUp()
	t.test_init()
	t.test_print_even_numebrs()	
	
	
	
